<?php

/*
 *
 *   _____       _                          _
 *  / ____|     | |                        (_)
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\inventory;

use pocketmine\BedrockPlayer;
use pocketmine\math\Vector3;
use pocketmine\network\bedrock\protocol\ContainerClosePacket as BedrockContainerClose;
use pocketmine\network\mcpe\protocol\ContainerClosePacket;
use pocketmine\network\mcpe\protocol\ContainerOpenPacket;
use pocketmine\Player;

abstract class ContainerInventory extends BaseInventory{

	public function onOpen(Player $who){
		parent::onOpen($who);

		$pk = new ContainerOpenPacket();
		$pk->windowId = $who->getWindowId($this);
		$pk->type = $this->getType()->getNetworkType();
		$holder = $this->getHolder();
		if($holder instanceof Vector3){
			$pk->x = $holder->getX();
			$pk->y = $holder->getY();
			$pk->z = $holder->getZ();
		}else{
			$pk->x = $pk->y = $pk->z = 0;
		}

		$who->sendDataPacket($pk);
        $who->setCurrentWindowType($this->getType()->getNetworkType());
		$this->sendContents($who);
	}

	public function onClose(Player $who){
		if($who instanceof BedrockPlayer){
			$pk = new BedrockContainerClose();
			$pk->windowId = $who->getWindowId($this);
            $pk->windowType = $this->getType()->getNetworkType();
			$pk->server = $who->getClientClosingWindowId() !== $pk->windowId;
			$who->sendDataPacket($pk);
		}else{
			$pk = new ContainerClosePacket();
			$pk->windowId = $who->getWindowId($this);
			$who->sendDataPacket($pk);
		}

		parent::onClose($who);
	}
}