<?php

/*
 *
 *   _____       _                          _
 *  / ____|     | |                        (_)
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\inventory;

use pocketmine\math\Vector3;

class WindowHolder extends Vector3 implements InventoryHolder{
	/** @var WindowInventory */
	protected $inventory;

	public function __construct(WindowInventory $inventory){
		parent::__construct();

		$this->inventory = $inventory;
	}

	/**
	 * @return Inventory
	 */
	public function getInventory() : Inventory{
		return $this->inventory;
	}
}