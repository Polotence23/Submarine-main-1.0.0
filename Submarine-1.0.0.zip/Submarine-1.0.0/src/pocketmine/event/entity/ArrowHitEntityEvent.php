<?php

/*
 *
 *   _____       _                          _
 *  / ____|     | |                        (_)
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

namespace pocketmine\event\entity;

use pocketmine\entity\EffectInstance;
use pocketmine\entity\Entity;

class ArrowHitEntityEvent extends EntityEvent{
	public static $handlerList = null;

	/** @var Entity */
	private $entityHit;
    /** @var null|EffectInstance */
    private $effect;
    /** @var bool */
    private $isPunch;

	public function __construct(Entity $entity, Entity $entityHit, null|EffectInstance $effect, bool $punch){
        $this->entity = $entity;
		$this->entityHit = $entityHit;
        $this->effect = $effect;
        $this->isPunch = $punch;
	}

	/**
	 * Returns the Entity struck by the projectile.
	 *
	 * @return Entity
	 */
	public function getEntityHit() : Entity{
		return $this->entityHit;
	}

    public function getEffect() : null|EffectInstance{
        return $this->effect;
    }

    public function setEffect(null|EffectInstance $effect) : void{
        $this->effect = $effect;
    }

    public function isPunch() : bool{
        return $this->isPunch;
    }

    public function setPunch(bool $punch) : void{
        $this->isPunch = $punch;
    }
}