<?php

/*
 *
 *   _____       _                          _
 *  / ____|     | |                        (_)
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\event\entity;

use pocketmine\entity\EffectInstance;
use pocketmine\entity\Entity;

/**
 * Called when an effect is added to an Entity.
 */
class EntityEffectAddEvent extends EntityEffectEvent{
    public static $handlerList = null;

    /** @var EffectInstance|null */
    private $oldEffect;

    /**
     * @param Entity         $entity
     * @param EffectInstance $effect
     * @param EffectInstance $oldEffect
     */
    public function __construct(Entity $entity, EffectInstance $effect, EffectInstance $oldEffect = null){
        parent::__construct($entity, $effect);
        $this->oldEffect = $oldEffect;
    }

    /**
     * Returns whether the effect addition will replace an existing effect already applied to the entity.
     *
     * @return bool
     */
    public function willModify() : bool{
        return $this->hasOldEffect();
    }

    /**
     * @return bool
     */
    public function hasOldEffect() : bool{
        return $this->oldEffect instanceof EffectInstance;
    }

    /**
     * @return EffectInstance|null
     */
    public function getOldEffect() : ?EffectInstance{
        return $this->oldEffect;
    }
}