<?php

/*
 *
 *   _____       _                          _
 *  / ____|     | |                        (_)
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\event\level;

use pocketmine\event\Event;

/**
 * Called when a Level is loaded
 */
class LevelCreationEvent extends Event{
	public static $handlerList = null;

    public function __construct(
        private readonly string $levelName,
        private string $levelClass
    ) {}

    public function getLevelName() : string{
        return $this->levelName;
    }

    public function setLevelClass(string $class) : void{
        $this->levelClass = $class;
    }

    public function getLevelClass() : string{
        return $this->levelClass;
    }
}