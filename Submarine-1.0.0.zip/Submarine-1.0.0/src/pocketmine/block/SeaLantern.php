<?php

/*
 * 
 *   _____       _                          _            
 *  / ____|     | |                        (_)           
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___ 
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|                                                                    
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\block;

use pocketmine\item\Item;

class SeaLantern extends Transparent{

	protected $id = self::SEA_LANTERN;

	public function __construct(int $meta = 0){
		$this->meta = $meta;
	}

    public function getName() : string{
        return "Sea Lantern";
    }

    public function getHardness() : float{
        return 0.3;
    }

    public function getLightLevel() : int{
        return 15;
    }

    public function getDropsForCompatibleTool(Item $item) : array{
        return [
            Item::get(Item::PRISMARINE_CRYSTALS, 0, 3)
        ];
    }
}
