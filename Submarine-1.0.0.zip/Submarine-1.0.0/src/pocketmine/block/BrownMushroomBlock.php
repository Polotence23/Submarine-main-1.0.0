<?php

/*
 *
 *   _____       _                          _
 *  / ____|     | |                        (_)
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\block;

use pocketmine\item\Item;
use function mt_rand;

class BrownMushroomBlock extends RedMushroomBlock{

    protected $id = Block::BROWN_MUSHROOM_BLOCK;

    public function getName() : string{
        return "Brown Mushroom Block";
    }

    public function getDropsForCompatibleTool(Item $item) : array{
        return [
            Item::get(Item::BROWN_MUSHROOM, 0, mt_rand(0, 2))
        ];
    }
}
