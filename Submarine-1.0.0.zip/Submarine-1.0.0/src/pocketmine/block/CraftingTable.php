<?php

/*
 *
 *   _____       _                          _
 *  / ____|     | |                        (_)
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\block;

use pocketmine\BedrockPlayer;
use pocketmine\item\Item;
use pocketmine\network\bedrock\protocol\ContainerOpenPacket;
use pocketmine\network\bedrock\protocol\types\inventory\WindowTypes;
use pocketmine\network\mcpe\protocol\types\ContainerIds;
use pocketmine\Player;

class CraftingTable extends Solid{

	protected $id = self::CRAFTING_TABLE;

	public function __construct(int $meta = 0){
		$this->meta = $meta;
	}

    public function getHardness() : float{
        return 2.5;
    }

    public function getName() : string{
        return "Crafting Table";
    }

    public function getToolType() : int{
        return BlockToolType::TYPE_AXE;
    }

    public function onActivate(Item $item, Player $player = null) : bool{
		if($player instanceof Player){
			$player->craftingType = Player::CRAFTING_BIG;

			if($player instanceof BedrockPlayer and $player->newInventoryOpen(ContainerIds::INVENTORY)){
				$pk = new ContainerOpenPacket();
				$pk->windowId = ContainerIds::INVENTORY;
				$pk->type = WindowTypes::WORKBENCH;
				[$pk->x, $pk->y, $pk->z] = [$this->x, $this->y, $this->z];
				$player->sendDataPacket($pk);

                $player->setCurrentWindowType(WindowTypes::WORKBENCH);
			}
		}

		return true;
	}

    public function getFuelTime() : int{
        return 300;
    }
}
