<?php

/*
 *
 *   _____       _                          _
 *  / ____|     | |                        (_)
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\block;

use pocketmine\item\Hoe;
use pocketmine\item\Item;
use pocketmine\Player;

class Dirt extends Solid{

	protected $id = self::DIRT;

	public function __construct(int $meta = 0){
		$this->meta = $meta;
	}

    public function getHardness() : float{
        return 0.5;
    }

    public function getToolType() : int{
        return BlockToolType::TYPE_SHOVEL;
    }

    public function getName() : string{
        if($this->meta === 1){
            return "Coarse Dirt";
        }
        return "Dirt";
    }

    public function onActivate(Item $item, Player $player = null) : bool{
        if($item instanceof Hoe){
            $item->applyDamage(1);
            if($this->meta === 1){
                $this->getLevel()->setBlock($this, Block::get(Block::DIRT), true);
            }else{
                $this->getLevel()->setBlock($this, Block::get(Block::FARMLAND), true);
            }

            return true;
        }

        return false;
    }
}