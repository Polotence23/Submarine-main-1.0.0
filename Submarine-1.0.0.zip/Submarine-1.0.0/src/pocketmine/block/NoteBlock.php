<?php

/*
 * 
 *   _____       _                          _            
 *  / ____|     | |                        (_)           
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___ 
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|                                                                    
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\tile\NoteBlock as TileNoteBlock;
use pocketmine\tile\Tile;

class NoteBlock extends Solid{

	protected $id = self::NOTE_BLOCK;

	public function __construct(int $meta = 0){
		$this->meta = $meta;
	}

    public function getHardness() : float{
        return 0.8;
    }

    public function getToolType() : int{
        return BlockToolType::TYPE_AXE;
    }

    public function place(Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, Player $player = null) : bool{
        $this->getLevel()->setBlock($blockReplace, $this, true, true);
        Tile::createTile(Tile::NOTE_BLOCK, $this->getLevel(), TileNoteBlock::createNBT($this, $face, $item, $player));
        return true;
    }

    public function onActivate(Item $item, Player $player = null) : bool{
        $tile = $this->level->getTile($this);
        if($tile instanceof TileNoteBlock){
            $tile->changePitch();

            return $tile->triggerNote();
        }

        return false;
    }

    public function getName() : string{
        return "Noteblock";
    }

    public function getFuelTime() : int{
        return 300;
    }
}
