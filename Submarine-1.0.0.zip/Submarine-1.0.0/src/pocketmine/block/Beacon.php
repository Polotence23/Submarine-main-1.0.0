<?php

/*
 *
 *   _____       _                          _
 *  / ____|     | |                        (_)
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\tile\Beacon as TileBeacon;
use pocketmine\tile\Tile;

class Beacon extends Transparent
{

    protected $id = self::BEACON;

    public function __construct(int $meta = 0)
    {
        $this->meta = $meta;
    }

    public function getName() : string{
        return "Beacon";
    }

    public function getLightLevel() : int{
        return 15;
    }

    public function getHardness() : float{
        return 3;
    }

    public function getBreakTime(Item $item) : float{
        return 4.5;
    }

    public function place(Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, Player $player = null): bool
    {
        $this->getLevel()->setBlock($this, $this, true, true);

        Tile::createTile(Tile::BEACON, $this->getLevel(), TileBeacon::createNBT($this, $face, $item, $player));
        return true;
    }

    public function onActivate(Item $item, Player $player = null) : bool{
        if ($player instanceof Player) {
            $tile = $this->level->getTile($this);
            if (!$tile instanceof TileBeacon) {
                $tile = Tile::createTile(Tile::BEACON, $this->getLevel(), TileBeacon::createNBT($this, null, $item, $player));
            }
            if ($tile instanceof TileBeacon) {
                $top = $this->getSide(Vector3::SIDE_UP);
                if ($top->isTransparent() !== true) {
                    return true;
                }

                $player->addWindow($tile->getInventory());
            }
        }
        return true;
    }
}