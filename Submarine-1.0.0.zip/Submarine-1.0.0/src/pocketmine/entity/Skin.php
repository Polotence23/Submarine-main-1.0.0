<?php

/*
 *
 *   _____       _                          _
 *  / ____|     | |                        (_)
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\entity;

use pocketmine\network\bedrock\protocol\types\skin\Skin as BedrockSkin;
use pocketmine\network\bedrock\skin\SkinConverter as BedrockSkinConverter;
use pocketmine\network\mcpe\protocol\types\Skin as McpeSkin;
use pocketmine\network\mcpe\skin\SkinConverter as McpeSkinConverter;

class Skin{

	/** @var McpeSkin */
	protected $mcpeSkin;
	/** @var BedrockSkin */
	protected $bedrockSkin;

    public static function fromSkinDataId(string $skinId, string $skinData) : self{
        $skin = new McpeSkin($skinId, $skinData);
        return self::fromMcpeSkin($skin);
    }

	public static function fromMcpeSkin(McpeSkin $mcpeSkin) : self{
		$bedrockSkin = BedrockSkinConverter::convert($mcpeSkin);
		return new self($mcpeSkin, $bedrockSkin);
	}

	public static function fromBedrockSkin(BedrockSkin $bedrockSkin) : self{
		$mcpeSkin = McpeSkinConverter::convert($bedrockSkin);
		return new self($mcpeSkin, $bedrockSkin);
	}

	public function __construct(McpeSkin $mcpeSkin, BedrockSkin $bedrockSkin){
		$this->mcpeSkin = $mcpeSkin;
		$this->bedrockSkin = $bedrockSkin;
	}

	/**
	 * @return bool
	 */
	public function isValid() : bool{
		return $this->mcpeSkin !== null and $this->bedrockSkin !== null and $this->mcpeSkin->isValid() and $this->bedrockSkin->isValid();
	}

	/**
	 * @return McpeSkin
	 */
	public function getMcpeSkin() : McpeSkin{
		return $this->mcpeSkin;
	}

	/**
	 * @return BedrockSkin
	 */
	public function getBedrockSkin() : BedrockSkin{
		return $this->bedrockSkin;
	}
}