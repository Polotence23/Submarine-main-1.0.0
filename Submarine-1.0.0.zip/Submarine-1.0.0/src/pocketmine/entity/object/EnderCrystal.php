<?php

/*
 *
 *   _____       _                          _
 *  / ____|     | |                        (_)
 * | (___  _   _| |__  _ __ ___   __ _ _ __ _ _ __   ___
 *  \___ \| | | | '_ \| '_ ` _ \ / _` | '__| | '_ \ / _ \
 *  ____) | |_| | |_) | | | | | | (_| | |  | | | | |  __/
 * |_____/ \__,_|_.__/|_| |_| |_|\__,_|_|  |_|_| |_|\___|
 *
 * This program is private software. No license required.
 * Publication of this program is forbidden and will be punished.
 *
 * @author SEMENNEJO
 * @link vk.com/vk.snikers
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\entity\object;

use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\ExplosionPrimeEvent;
use pocketmine\level\Explosion;
use pocketmine\level\Position;

class EnderCrystal extends Entity{

	public const NETWORK_ID = self::ENDER_CRYSTAL;

	public float $height = 0.98;
	public float $width = 0.98;
	public float $gravity = 0.0;
	public float $drag = 0.0;

    public function updateMovement(bool $teleport = false) : void{
        // NOOP
    }

    public function isFireProof(): bool{
        return true;
    }

    public function attack(EntityDamageEvent $source): void
    {
		parent::attack($source);
        if(!$this->isFlaggedForDespawn() and !$source->isCancelled() and $source->getCause() !== EntityDamageEvent::CAUSE_FIRE and $source->getCause() !== EntityDamageEvent::CAUSE_FIRE_TICK) {
            $this->flagForDespawn();
            $ev = new ExplosionPrimeEvent($this, 6); //TODO: dropitem зависит от того, в креативе ли игрок
            $ev->call();
            if (!$ev->isCancelled()) {
                $explosion = new Explosion(Position::fromObject($this->add(0, $this->height / 2, 0), $this->level), $ev->getForce(), $this);

                if($ev->isBlockBreaking()){
                    $explosion->explodeA();
                }
                $explosion->explodeB();
            }
        }
	}

    public function setShowBase(bool $value) : void{
        $this->setGenericFlag(self::DATA_FLAG_SHOWBASE, $value);
    }

    public function showBase() : bool{
        return $this->getGenericFlag(self::DATA_FLAG_SHOWBASE);
    }
}