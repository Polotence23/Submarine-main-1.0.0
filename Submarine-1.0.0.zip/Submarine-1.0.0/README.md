Submarine is a fork of AquaMine
